import pygame
from pygame.locals import *

import sys
from pygame.rect import Rect

pygame.init()
x = (384)
y = (288)
NBx = 210
NBy = 302
NBx1 = 485
NBy1 = 500

white = (255, 255, 255, 255)
OKNOGRY = pygame.display.set_mode((816, 624), 0, 32)
pygame.display.set_caption('SAPER')
robotImg = pygame.image.load('robot.png')
mapImg = pygame.image.load('mapaSaper.png')
map2Img = pygame.image.load('budynek1.png')
map3Img = pygame.image.load('budynek2.png')
CzB = pygame.image.load('CzB.png')
NB = pygame.image.load('NB.gif')
ZB = pygame.image.load('ZB.png')
pole = 110
NBpole = 106
change_map = mapImg
przewoz=0


# 0- puste (może przejechać), 1- zajęte ( nie może przejechać), 2- budynek(może wjechać do środka),
#3 - wej�cie do budynku,4 - bomba 9#wyjście z map3,5-woda,6-tablica,7-hehe my
map = [1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0,
       5, 5, 0, 1, 3, 3, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0,
       0, 5, 5, 5, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0,
       0, 1, 1, 5, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 2, 2, 0,
       0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0,
       0, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1,
       0, 0, 0, 1, 4, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1,
       1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1,
       1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0,
       0, 0, 0, 6, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1,
       5, 5, 5, 5, 0, 5, 5, 5, 5, 0, 0, 0, 5, 5, 5, 1, 1,
       0, 0, 0, 5, 0, 5, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0,
       1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 5, 5, 5, 1, 1, 0]

map2 = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1,
        1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1,
        1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
        1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
        1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1,
        1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1,
        0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 8, 8, 8, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 8, 8, 8, 1, 1]

map3 = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 7, 1,
       0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1,
       1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1,
       1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 9, 0, 0]

map_general = map

def krata():
    for i in range(0,13):
        for j in range(0,17):

            pygame.draw.rect(OKNOGRY, (0,0,0), Rect((j*48,i*48),(48,48)), 1)


def szukanieBomby():
    for i in range(0,17):
        for j in range(0,13):

            pole = i*17+j
            x = j*48+24 #środek pola
            y = i*48+24 #środek pola
def robot(x, y):
	OKNOGRY.blit(robotImg, (x, y))
def fNB(NBx,NBy):
        OKNOGRY.blit(NB, (NBx, NBy))
print("     Witaj w grze Saper! Pom� robotowi Leny'emu ochroni� mieszka�c�w rozbrajaj�c niebezpieczne �adunki wybuchowe! Rozka� robotowi si� przedstawi�, aby uzyska� dodatkowe informacje. Mo�esz si� r�wnie� przywita�, zapewniamy, �e ch�tnie odpowie. Dobrej zabawy i powodzenia!")
while True:


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    OKNOGRY.blit(change_map, (0, 0))
    robot(x, y)
    fNB(NBx, NBy)
    #fNB(NBx1, NBy1)
    pygame.display.update()
    x_change = 0
    y_change = 0
    currentX = x
    currentY = y
    currentPole = pole
    NBpole
    
    robic = raw_input ('Co mam zrobi�?   ')
    if robic == ('jedz') or robic == ('jed�'):
        move = raw_input('W kt�r� stron� mam jecha�?    ')
        if move == ("w") or move == ("gora") or move == ("g�ra") or move == ("p�noc") or move == ("polnoc"):
            y_change = -48
            pole += -17
        elif move == ("s") or move == ("d�") or move == ("po�udnie") or move == ("dol") or move == ("poludnie"):
           y_change = +48
           pole += 17
        elif move == ("a") or move == ("lewo") or move == ("zachod") or move == ("zach�d"):
            x_change = -48
            pole += -1
        elif move == ("d") or move == ("prawo") or move == ("wschod") or move == ("wsch�d"):
            x_change = +48
            pole += 1

        x += x_change
        y += y_change

        if x > 816 - 48:
            x = 816 - 48
            pole = currentPole
        if x < 0:
            x = 0
            pole = currentPole
        if y > 624 - 48:
            y = 624 - 48
            pole = currentPole
        if y < 0:
            y = 0
            pole = currentPole

        if map_general[pole] == 0:
          robot(x,y)
          if (przewoz==1):
              map[NBpole]=0
              map[pole]=4
              NBpole=pole
              NBx=x+12
              NBy=y+12
              fNB(NBx,NBy)
              
        elif map_general[pole] == 1:
          print("       B��D! Nie mog� wjecha� na wskazan� pozycj�.")
          robot(currentX, currentY)
          pole = currentPole
          x= currentX
          y= currentY
        elif map_general[pole] == 5:
          print('       W fabryce nie nauczyli mnie p�ywa�!')
          robot(currentX, currentY)
          pole = currentPole
          x= currentX
          y= currentY
        elif map_general[pole] == 6:
          print('    Znalaz�em znak:')
          print('   "P�nosc - Temeria, Zach�d - Tatooine')
          print('    Po�udnie - Shire, Wsch�d - Hogwart"')
          robot(currentX, currentY)
          pole = currentPole
          x= currentX
          y= currentY
        elif map_general[pole] == 7:
          print('   Autor�w projektu trzymamy w tej piwnicy:')
          print('       Igor Misiorny')
          print('       Bartosz Szuka�a')
          print('       Micha� �mieszek')
          print('       Gracjan Walch')
          print('       Rafa� �ebrowski')
          print("   I nie, nie wypu�cimy, mog� si� jeszcze przyda�.")
          robot(currentX, currentY)
          pole = currentPole
          x= currentX
          y= currentY
        elif map_general[pole] == 2:
            print('     Wszed�em do budynku.')
            robot(currentX, currentY)
            pole = currentPole
            x = currentX
            y = currentY
            change_map = map2Img
            map_general = map2
            pole = 183
            OKNOGRY.blit(change_map, (0, 0))
            x = 624
            y = 480
            robot(x, y)
        elif map_general[pole] == 3:
            print("     Jestem w �rodku." )
            robot(currentX, currentY)
            pole = currentPole
            x = currentX
            y = currentY
            change_map = map3Img
            map_general = map3
            pole = 201
            OKNOGRY.blit(change_map, (0, 0))
            x = 672
            y = 528
            robot(x, y)

        elif map_general[pole] == 9:
            print('     Wyszed�em z budynku.')
            robot(currentX, currentY)
            pole = currentPole
            x = currentX
            y = currentY
            change_map = mapImg
            map_general = map
            pole = 39
            OKNOGRY.blit(change_map, (0, 0))
            x = 240
            y = 96
            robot(x, y)

        elif map_general[pole] == 8:
            print('     Jestem na zewn�trz.')
            robot(currentX, currentY)
            pole = currentPole
            x = currentX
            y = currentY
            change_map = mapImg
            map_general = map
            pole = 82
            OKNOGRY.blit(change_map, (0, 0))
            x = 672
            y = 192
            robot(x, y)
            
        
    elif robic == ('wez') or robic == ('we�') or robic == ('zabierz') or robic == ('podnies') or robic == ('podnies'):
        if map_general[pole] == 4 and przewoz == 0:
            przewoz=1
            print('     Bomba zabrana.')
        elif przewoz == 1:
            print ('    Trzymam bomb�.')
        else:
            print ("    Nic tu nie ma.")
                
    elif robic == ('zostaw') or robic == ('odstaw') or robic == ('po��') or robic == ('poloz') or robic == ('odloz') or robic == ('od��'):
        if przewoz==1:
            przewoz=0
            print("     Bomba od�o�ona.")
        else:
            print("     Nie mam bomby.")
    elif robic == ('przedstaw sie!') or robic == ('przedstaw sie') or robic == ('przedstaw si�!') or robic == ('przedstaw si�'):
        print("     Nazwa: Leny. Model T66X-P v. 2.08. Stworzony przez 'EkipaKCK�' ")
    elif robic == ('witam') or robic == ('czesc') or robic == ('cze��') or robic == ('siema') or robic == ('dzien dobry') or robic == ('dzie� dobry') or robic == ('hej'):
        print('     Witam :)')
    elif robic ==(':(') or robic ==('xd') or robic ==('xD') or robic ==(':P') or robic ==(';)') or robic ==(':)') or robic ==(':D'):
        print('     :)')
    else: print("      B��D! Nie rozpoznano polecenia.")
    pygame.display.update()

