saper_v2 jest tym nowsza wersja, z zakomentowanym ruchem na polecenia. 
saper.py jest pokazowy 